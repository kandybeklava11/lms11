public class School {

    private String name;
    private  int year;
    private String location;

    public String getName() {
        return name;
    }

    public int getYear() {
        return year;
    }

    public String getLocation() {
        return location;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setLocation(String location) {
        this.location = location;
    }


}
