import javax.swing.plaf.SpinnerUI;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        //My class
//        String[] Lessons1 = {"Tecnical lesson"};
//        MyClass person =new MyClass("Kandybek","Isaev", 16,Lessons1 , "Lagman");
//       person.Demokrat();
//        System.out.println();
//       MyClass person2=new MyClass();
//       person2.Demokrat();

                Person[] person = new Person[3];
                person[0] = new Person();
                person[0].setName("Muktar");
                person[0].setAge(17);

                person[1] = new Person();
                person[1].setName("Beka");
                person[1].setAge(17);

                person[2] = new Person();
                person[2].setName("Nurik");
                person[2].setAge(25);

                Car[] car = new Car[3];
                car[0] = new Car();
                car[0].setMarka("Honda");
                car[0].setYaer(2014);
                car[0].setPrice("20000$");

                car[1] = new Car();
                car[1].setMarka("Nissan");
                car[1].setYaer(2004);
                car[1].setPrice("9000$");

                car[2] = new Car();
                car[2].setMarka("Lexus");
                car[2].setYaer(2023);
                car[2].setPrice("100000$");

                School[] school = new School[3];
                school[0] = new School();
                school[0].setName("№66");
                school[0].setYear(1950);
                school[0].setLocation("Bishkek");

                school[1] = new School();
                school[1].setName("№72");
                school[1].setYear(1968);
                school[1].setLocation("Bishkek");

                school[2] = new School();
                school[2].setName("№40");
                school[2].setYear(1976);
                school[2].setLocation("Bishkek");

                University[] university = new University[3];
                university[0] = new University();
                university[0].setName("Jusup Balasagyn");
                university[0].setYear(1934);
                university[0].setLocation("Kara Balta");

                university[1] = new University();
                university[1].setName("Manas");
                university[1].setYear(1956);
                university[1].setLocation("Bishkek");

                university[2] = new University();
                university[2].setName("Sayakbai Karalaev");
                university[2].setYear(1943);
                university[2].setLocation("Bishkek");

                System.out.println("Schools:");
                for (School scu : school) {
                    System.out.println(scu.getName() + " - " + scu.getYear() + " - " + scu.getLocation());
                }
        System.out.println();
                System.out.println("Universities:");
                for (University univ : university) {
                    System.out.println(univ.getName() + " - " + univ.getYear() + " - " + univ.getLocation());
                }
        System.out.println();
                System.out.println("Cars:");
                for (Car cr : car) {
                    System.out.println(cr.getMarka() + " - " + cr.getYaer() + " - " + cr.getPrice());
                }
        System.out.println();
                System.out.println("Persons:");
                for (Person pr : person) {
                    System.out.println(pr.getName() + " - " + pr.getAge());
                }
            }
        }